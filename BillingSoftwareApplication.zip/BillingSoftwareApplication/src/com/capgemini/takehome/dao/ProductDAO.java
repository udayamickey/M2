package com.capgemini.takehome.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.takehome.Exception.TakeHomeException;
import com.capgemini.takehome.bean.ProductBean;
import com.capgemini.takehome.utility.JdbcUtility;




public class ProductDAO implements IProductDAO {
	static Logger logger = Logger.getLogger(ProductDAO.class);
	Connection connection = null;
	PreparedStatement statement = null;
	@Override
	public ProductBean getProductByCode(int code) throws TakeHomeException {
		logger.info("in getProductByCode method..");

		
		connection = JdbcUtility.getConnection();
		ProductBean p;
		try{
			statement = connection.prepareStatement(QueryMappers.selectQuery);
			statement.setInt(1, code);
			
			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
				p=new ProductBean();
				
				p.setProduct_name(resultSet.getString(2));
				p.setProduct_category(resultSet.getString(3));
				p.setProduct_description(resultSet.getString(4));
				p.setProduct_price(resultSet.getDouble(5));
				//System.out.println(p);
			return p;
			
		
	}catch(SQLException e)
		{logger.error("statement not created..");
		
		throw new TakeHomeException("statement not created");
		}
	}
}
	
	
	

