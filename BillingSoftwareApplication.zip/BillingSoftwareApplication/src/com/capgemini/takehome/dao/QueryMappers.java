package com.capgemini.takehome.dao;

public interface QueryMappers {
	public static final String selectQuery = "select * from product where product_code=?";
}
