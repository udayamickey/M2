package com.cap.bs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cap.bs.bean.ProductBean;
import com.cap.bs.exception.BSException;
import com.cap.bs.util.DBConnection;

public class ProductDaoImpl implements IProductDao{

	@Override
	public ProductBean getProductDetails(Integer product_code) throws BSException {
		try(Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select * from product where product_code=?");
				){
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next()){
				ProductBean product=new ProductBean();
				populateProductDetails(product,resultSet);
				return product;
			}
		}catch(SQLException e){
			
		}
		return null;
	}

	private void populateProductDetails(ProductBean product, ResultSet resultSet) throws SQLException {
		product.setProduct_code(resultSet.getInt(1));
		product.setProduct_name(resultSet.getString(2));
		product.setProduct_cat(resultSet.getString(3));
		product.setProduct_des(resultSet.getString(4));
		product.setProduct_price(resultSet.getDouble(5));
		
		
	}

	@Override
	public boolean insertSalesDetails(ProductBean product,Integer quantity) throws BSException {
		
			try(Connection connection=DBConnection.getConnection();
					PreparedStatement preparedStatement = connection.prepareStatement("insert into sales values(salesId.NEXTVAL,?,?,SYSDATE,?)");
					PreparedStatement ps=connection.prepareStatement("select product_price from product where product_code=?");
					
					){
		ps.setInt(1, product.getProduct_code());
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			Double price=(quantity*rs.getDouble(1));
		
		preparedStatement.setInt(1, product.getProduct_code());
		preparedStatement.setInt(2, quantity);
		preparedStatement.setDouble(3, price);
		int n=preparedStatement.executeUpdate();
		if(n!=0){
			return true;
		}
		}
			}catch(SQLException e){
				
			}
			
		return false;
	}

	@Override
	public boolean validProductCode(Integer pCode) throws BSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select * from product where product_code=?")
				
				){
			preparedStatement.setInt(1,pCode);
			ResultSet rs= preparedStatement.executeQuery();
			if(rs.next()){
				
				return true;
			}		}catch(SQLException e){
				
			}
		return false;
	}

}
