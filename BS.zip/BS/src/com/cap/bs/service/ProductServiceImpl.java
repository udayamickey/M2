package com.cap.bs.service;

import com.cap.bs.bean.ProductBean;
import com.cap.bs.dao.IProductDao;
import com.cap.bs.dao.ProductDaoImpl;
import com.cap.bs.exception.BSException;

public class ProductServiceImpl implements IProductService{
	private IProductDao productDao=new ProductDaoImpl();

	@Override
	public ProductBean getProductDetails(Integer product_code)
			throws BSException {
		ProductBean product=new ProductBean();
		product=productDao.getProductDetails(product_code);
		return product;
	}

	@Override
	public boolean insertSalesDetails(ProductBean product, Integer quantity)
			throws BSException {
		
		return productDao.insertSalesDetails(product, quantity);
	}

	@Override
	public boolean validProductCode(Integer pCode) throws BSException {
		
		return productDao.validProductCode(pCode);
	}

}
