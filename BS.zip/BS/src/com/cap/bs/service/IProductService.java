package com.cap.bs.service;

import com.cap.bs.bean.ProductBean;
import com.cap.bs.exception.BSException;

public interface IProductService {
	public abstract ProductBean getProductDetails(Integer product_code)throws BSException;
	public abstract boolean insertSalesDetails(ProductBean product,Integer quantity)throws BSException;
	public abstract boolean validProductCode(Integer pCode)throws BSException;

}
