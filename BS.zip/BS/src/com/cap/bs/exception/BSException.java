package com.cap.bs.exception;

public class BSException extends Exception{
	private String message;

	public BSException(String message) {
		super();
		this.message = message;
	}

	public BSException() {
		super();
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "BSException [message=" + message + "]";
	}
	

}
