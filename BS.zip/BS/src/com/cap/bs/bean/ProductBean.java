package com.cap.bs.bean;

public class ProductBean {
	private Integer product_code;
	private String product_name;
	private String product_cat;
	private String product_des;
	private Double product_price;
	
	public ProductBean() {
		super();
	}

	public ProductBean(Integer product_code, String product_name,
			String product_cat, String product_des, Double product_price) {
		super();
		this.product_code = product_code;
		this.product_name = product_name;
		this.product_cat = product_cat;
		this.product_des = product_des;
		this.product_price = product_price;
	}

	public Integer getProduct_code() {
		return product_code;
	}

	public void setProduct_code(Integer product_code) {
		this.product_code = product_code;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_cat() {
		return product_cat;
	}

	public void setProduct_cat(String product_cat) {
		this.product_cat = product_cat;
	}

	public String getProduct_des() {
		return product_des;
	}

	public void setProduct_des(String product_des) {
		this.product_des = product_des;
	}

	public Double getProduct_price() {
		return product_price;
	}

	public void setProduct_price(Double product_price) {
		this.product_price = product_price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((product_cat == null) ? 0 : product_cat.hashCode());
		result = prime * result
				+ ((product_code == null) ? 0 : product_code.hashCode());
		result = prime * result
				+ ((product_des == null) ? 0 : product_des.hashCode());
		result = prime * result
				+ ((product_name == null) ? 0 : product_name.hashCode());
		result = prime * result
				+ ((product_price == null) ? 0 : product_price.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductBean other = (ProductBean) obj;
		if (product_cat == null) {
			if (other.product_cat != null)
				return false;
		} else if (!product_cat.equals(other.product_cat))
			return false;
		if (product_code == null) {
			if (other.product_code != null)
				return false;
		} else if (!product_code.equals(other.product_code))
			return false;
		if (product_des == null) {
			if (other.product_des != null)
				return false;
		} else if (!product_des.equals(other.product_des))
			return false;
		if (product_name == null) {
			if (other.product_name != null)
				return false;
		} else if (!product_name.equals(other.product_name))
			return false;
		if (product_price == null) {
			if (other.product_price != null)
				return false;
		} else if (!product_price.equals(other.product_price))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ProductBean [product_code=" + product_code + ", product_name="
				+ product_name + ", product_cat=" + product_cat
				+ ", product_des=" + product_des + ", product_price="
				+ product_price + "]";
	}
	

}
